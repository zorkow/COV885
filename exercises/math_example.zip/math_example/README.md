Source: https://arxiv.org/abs/1312.4289
